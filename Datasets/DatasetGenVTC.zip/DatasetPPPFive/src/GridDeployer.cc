#include "GridDeployer.h"
#include <cmath>
#include <random>
#include <algorithm>
Define_Module(GridDeployer);
void GridDeployer::initialize()
{
    //gridId = par("gridId");
    createGrids();
    deployGNBs();
    drawGridLines();
    calculateGridCenters();
}
void GridDeployer::createGrids()
{
    double areaWidth = par("areaWidth");
    double areaHeight = par("areaHeight");
    double gridSize = par("gridSize");
    numGridsX = floor(areaWidth / gridSize);
    numGridsY = floor(areaHeight / gridSize);
    grids.resize(numGridsY * numGridsX);
    for (int y = 0; y < numGridsY; y++) {
        for (int x = 0; x < numGridsX; x++) {
            grids[y * numGridsX + x] = {x, y, false};
        }
    }

    EV << "Created " << grids.size() << " grids" << endl;
}
/*void GridDeployer::deployGNBs()
{
    double numGNBs = par("numGNBs");
    double areaWidth = par("areaWidth");
    double areaHeight = par("areaHeight");
    double gridSize = par("gridSize");
    std::vector<int> availableGridIndices(grids.size());
    std::iota(availableGridIndices.begin(), availableGridIndices.end(), 0);
    std::random_device rd;
    std::mt19937 g(rd());
    cModule *parent = getParentModule();
    int placedGNBs = 0;
    while (placedGNBs < numGNBs && !availableGridIndices.empty()) {
        std::uniform_int_distribution<> dis(0, availableGridIndices.size() - 1);
        int randomIndex = dis(g);
        int gridIndex = availableGridIndices[randomIndex];
        Grid& currentGrid = grids[gridIndex];
        // Calculate the center of the grid cell
        double x = (currentGrid.x + 0.5) * gridSize;
        double y = (currentGrid.y + 0.5) * gridSize;
        // Ensure the gNB is within the simulation area
        x = std::min(x, areaWidth);
        y = std::min(y, areaHeight);
        cModule *gnbModule = parent->getSubmodule("gnbs", placedGNBs);
        if (gnbModule) {
            gnbModule->par("x").setDoubleValue(x);
            gnbModule->par("y").setDoubleValue(y);
            gnbModule->par("pci").setIntValue(placedGNBs);
            EV << "Placed gNB" << placedGNBs << " at center of grid (" << currentGrid.x << "," << currentGrid.y
                    << ") at coordinates (" << x << ", " << y << ")" << endl;
            currentGrid.occupied = true;
            placedGNBs++;
            // Remove this grid and its neighbors from available grids
            availableGridIndices.erase(availableGridIndices.begin() + randomIndex);
        } else {
            EV << "gNB submodule at index " << placedGNBs << " does not exist" << endl;
            break;
        }
    }
    if (placedGNBs < numGNBs) {
        EV << "Warning: Could only place " << placedGNBs << " gNBs out of " << numGNBs << " requested." << endl;
    }
}*/


void GridDeployer::deployGNBs()
{
    double areaWidth = par("areaWidth");
    double areaHeight = par("areaHeight");
    double gridSize = par("gridSize");

    // Predefined grid positions for 15 gNBs (x,y grid coordinates)
    // Positions are non-contiguous to avoid interference
    const std::vector<std::pair<int, int>> gnbPositions = {

            /*{9, 8},    // gNB 0
            {17, 14},    // gNB 1
            {0, 7},    // gNB 2
            {4, 16},    // gNB 3
            {2, 19},    // gNB 4
            {19, 18},    // gNB 5
            {11, 14},    // gNB 6
            {6, 2},    // gNB 7
            {18, 1},    // gNB 8
            {1, 12},    // gNB 9
            {18, 6},    // gNB 10
            {9, 19},    // gNB 11
            {12, 4},    // gNB 12
            {6, 11},    // gNB 13
            {14, 15},    // gNB 14*/ /*VTC 50m*/

            /*{9, 0},    // gNB 0
                    {42, 6},    // gNB 1
                    {81, 4},    // gNB 2
                    {30, 29},    // gNB 3
                    {3, 33},    // gNB 4
                    {47, 41},    // gNB 5
                    {85, 50},    // gNB 6
                    {61, 67},    // gNB 7
                    {14, 57},    // gNB 8
                    {36, 68},    // gNB 9
                    {87, 73},    // gNB 10
                    {83, 24},    // gNB 11
                    {8, 96},    // gNB 12
                    {48, 90},    // gNB 13
                    {96, 99},    // gNB 14*/ /*for VTC 10m*/
            {6, 9},    // gNB 0
            {2, 1},    // gNB 1
            {9, 1},    // gNB 2
            {7, 2},    // gNB 3
            {1, 3},    // gNB 4
            {4, 3},    // gNB 5
            {1, 5},    // gNB 6
            {8, 5},    // gNB 7
            {5, 6},    // gNB 8
            {2, 7},    // gNB 9
            {9, 7},    // gNB 10
            {7, 8},    // gNB 11
            {1, 9},    // gNB 12
            {5, 9},    // gNB 13
            {9, 9},    // gNB 14 for VTC 100m
    };

    cModule *parent = getParentModule();
    double numGNBs = par("numGNBs");
    for (int i = 0; i < numGNBs; i++) {
        const auto& pos = gnbPositions[i];
        double gridX = pos.first;
        double gridY = pos.second;

        // Ensure the selected grid position is within bounds
        if (gridX >= numGridsX || gridY >= numGridsY) {
            EV << "Warning: Predefined position (" << gridX << "," << gridY << ") for gNB"
                    << i << " is outside grid bounds" << endl;
            continue;
        }

        // Calculate the center coordinates of the selected grid
        double x = (gridX + 0.5) * gridSize;
        double y = (gridY + 0.5) * gridSize;

        // Ensure coordinates don't exceed area bounds
        x = std::min(x, areaWidth);
        y = std::min(y, areaHeight);

        cModule *gnbModule = parent->getSubmodule("gnbs", i);
        if (gnbModule) {
            gnbModule->par("x").setDoubleValue(x);
            gnbModule->par("y").setDoubleValue(y);
            gnbModule->par("pci").setIntValue(i);

            // Mark the grid as occupied
            grids[gridY * numGridsX + gridX].occupied = true;

            EV << "Placed gNB" << i << " at center of grid (" << gridX << "," << gridY
                    << ") at coordinates (" << x << ", " << y << ")" << endl;
        } else {
            EV << "gNB submodule at index " << i << " does not exist" << endl;
            break;
        }
    }
}


void GridDeployer::drawGridLines()
{

    cCanvas *canvas = getParentModule()->getCanvas();
    double areaWidth = par("areaWidth");
    double areaHeight = par("areaHeight");
    double gridSize = par("gridSize");
    for (int x = 0; x <= numGridsX; x++) {
        cLineFigure *line = new cLineFigure();
        line->setStart(cFigure::Point(x * gridSize, 0));
        line->setEnd(cFigure::Point(x * gridSize, areaHeight));
        line->setLineColor(cFigure::GREY);
        line->setLineStyle(cFigure::LINE_DASHED);
        canvas->addFigure(line);
    }

    for (int y = 0; y <= numGridsY; y++) {
        cLineFigure *line = new cLineFigure();
        line->setStart(cFigure::Point(0, y * gridSize));
        line->setEnd(cFigure::Point(areaWidth, y * gridSize));
        line->setLineColor(cFigure::GREY);
        line->setLineStyle(cFigure::LINE_DASHED);
        canvas->addFigure(line);
    }

}



void GridDeployer::calculateGridCenters()
{
    double gridSize = par("gridSize");
    gridCenters.clear();
    gridCenters.reserve(grids.size());

    for (size_t i = 0; i < grids.size(); i++) {
        const Grid& currentGrid = grids[i];

        // Calculate center coordinates
        double centerX = (currentGrid.x + 0.5) * gridSize;
        double centerY = (currentGrid.y + 0.5) * gridSize;

        // Store grid information including index and center coordinates
        GridInfo info;
        info.index = i;
        info.gridX = currentGrid.x;
        info.gridY = currentGrid.y;
        info.centerX = centerX;
        info.centerY = centerY;
        info.occupied = currentGrid.occupied;

        gridCenters.push_back(info);

        EV << "Grid " << i << " at (" << currentGrid.x << "," << currentGrid.y
                << ") has center at (" << centerX << "," << centerY << ")" << endl;
    }
}
