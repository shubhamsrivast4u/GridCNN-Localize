#include "gNB.h"
#include <cmath>
Define_Module(gNB);
void gNB::initialize()
{
    x = par("x");
    y = par("y");
    pci = par("pci");
    cMessage *discoverMsg = new cMessage("discoverNeighbors");
    scheduleAt(simTime() + 0.1, discoverMsg);
}
void gNB::handleMessage(cMessage *msg)
{
    if (msg->isSelfMessage() && strcmp(msg->getName(), "discoverNeighbors") == 0) {
        discoverNeighbors();
    }
    delete msg;
}
void gNB::discoverNeighbors()
{
    double distTh = 500; // Discover neighbor cells within 500m

    cModule *parent = getParentModule();
    for (int i = 0; i < parent->getSubmoduleVectorSize("gnbs"); i++) {
        gNB *otherGNB = check_and_cast<gNB *>(parent->getSubmodule("gnbs", i));
        if (otherGNB != this) {
            double distance = calculateDistance(x, y, otherGNB->getX(), otherGNB->getY());
            if (distance <= distTh) {
                neighborPCIs.push_back(otherGNB->getPCI());
            }
        }
    }

    EV << "gNB " << pci << " at (" << x << ", " << y << ") has "
            << neighborPCIs.size() << " neighbors" << endl;
}
double gNB::calculateDistance(double x1, double y1, double x2, double y2)
{
    return std::sqrt(std::pow(x2 - x1, 2) + std::pow(y2 - y1, 2));
}
void gNB::ensureUEPortExists(int index)
{
    if (index >= gateSize("uePort")) {
        setGateSize("uePort", index + 1);
    }
}
