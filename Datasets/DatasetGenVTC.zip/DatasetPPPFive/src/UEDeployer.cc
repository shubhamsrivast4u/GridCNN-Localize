#include "UEDeployer.h"
#include "UE.h"
#include <random>
#include <cmath>
Define_Module(UEDeployer);
void UEDeployer::initialize()
{
    double areaWidth = par("areaWidth");
    double areaHeight = par("areaHeight");
    double lambda = par("lambda");
    int maxNumUEs = par("maxNumUEs");
    double area = areaWidth * areaHeight;
    // Generate Poisson Point Process
    std::vector<std::pair<double, double>> ueLocations = generatePPP(areaWidth, areaHeight, lambda, maxNumUEs);
    EV << "Deploying " << ueLocations.size() << " UEs" << endl;
    cModuleType *ueType = cModuleType::get("datasetpppfive.UE");
    for (size_t i = 0; i < ueLocations.size(); i++) {
        char ueName[32];
        sprintf(ueName, "ue%d", (int)i);
        cModule *ue = ueType->create(ueName, getParentModule());
        ue->par("x").setDoubleValue(ueLocations[i].first);
        ue->par("y").setDoubleValue(ueLocations[i].second);
        ue->finalizeParameters();
        ue->buildInside();
        ue->scheduleStart(simTime());
    }
}
std::vector<std::pair<double, double>> UEDeployer::generatePPP(double width, double height, double lambda, int maxPoints)
{
    std::vector<std::pair<double, double>> points;
    double area = width * height;
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> uniformDist(0, 1);

    // Generate number of points
    std::poisson_distribution<> poissonDist(lambda * area);
    int numPoints = std::min(poissonDist(gen), maxPoints);
    EV << "Number of UEs from POisson Dist. " << numPoints << endl;
    // Generate points
    for (int i = 0; i < numPoints; ++i) {
        double x = uniformDist(gen) * width;
        double y = uniformDist(gen) * height;
        points.emplace_back(x, y);
    }

    return points;
}
