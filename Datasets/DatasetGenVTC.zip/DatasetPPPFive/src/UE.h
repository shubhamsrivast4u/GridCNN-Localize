//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __DATASETPPPTHREE_UE_H_
#define __DATASETPPPTHREE_UE_H_

#include <omnetpp.h>
#include <vector>
#include <map>
#include <string>
#include <random>
#include <complex>
#include "GridDeployer.h"

using namespace omnetpp;

struct JsonValue {
    std::map<std::string, JsonValue> object;
    std::vector<JsonValue> array;
    std::string string;
    double number;
    bool isObject = false;
    bool isArray = false;
    bool isString = false;
    bool isNumber = false;
};

class gNB;

class UE : public cSimpleModule
{
private:
    double x;
    double y;
    int servingCellPCI;
    std::vector<int> neighborCellPCIs;
    JsonValue measurementReport;
    JsonValue gridReport;
    std::mt19937 rng;
    std::normal_distribution<> normal_dist;
    std::uniform_real_distribution<> uniform_dist;
    std::normal_distribution<double> thermalNoiseDist;
    std::normal_distribution<double> shadowingDist;    // Declared here

    void calculateMeasurements();
    void createGridDictionary();
    double calculateRSRP(double distance, double shadowing_db, double thermal_noise_watts);
    double calculateRSRQ(double rsrp, double rssi);
    double calculateRSSI(double distance, double shadowing_db, double thermal_noise_watts);
    double calculateInterference(double thermal_noise_watts);
    double calculateSINR(double rsrp, double interference, double noise);
    std::string jsonToString(const JsonValue& json, int indent = 0);
    double calculateDistance(double x1, double y1, double x2, double y2);
    void connectToCell(gNB *gnb, bool isServingCell);
    gNB* findGNBByPCI(int pci);
    void createVisualConnections();
    static JsonValue allUEData;
    static JsonValue allGridData;
    static bool dataInitialized;

protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    virtual void finish() override;


public:
    double getX() const { return x; }
    double getY() const { return y; }

};

#endif

