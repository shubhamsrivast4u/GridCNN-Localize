#include "UE.h"
#include "gNB.h"
#include "GridDeployer.h"
#include <cmath>
#include <random>
#include <fstream>
#include <sstream>
#include <omnetpp/ccanvas.h>
#include <omnetpp/cdisplaystring.h>

Define_Module(UE);

// --- STATIC VARIABLES ---
JsonValue UE::allUEData;
JsonValue UE::allGridData;
bool UE::dataInitialized = false;

// Counters to track simulation progress
static int totalUEsInitialized = 0; // Counts how many UEs exist
static int ueFinishedCount = 0;     // Counts how many have finished

/* --- PHYSICS CONSTANTS --- */
const double BW_HZ = 5000000.0;
const double THERMAL_NOISE_DENS_DBM = -174.0;
const double NOISE_FIGURE_DB = 7.0;

const double NOISE_FLOOR_DBM = THERMAL_NOISE_DENS_DBM + 10.0 * log10(BW_HZ) + NOISE_FIGURE_DB;
const double NOISE_MEAN_WATTS = pow(10.0, (NOISE_FLOOR_DBM - 30.0) / 10.0);
const double NOISE_SIGMA_WATTS = NOISE_MEAN_WATTS;

// --- CONFIGURATION ---
const int NUM_SAMPLES = 5;
const double SHADOWING_SIGMA_DB = 6.0;

void UE::initialize()
{
    // 1. Count this UE
    totalUEsInitialized++;

    x = par("x");
    y = par("y");

    cMessage *findCellsMsg = new cMessage("findCells");

    rng.seed(std::random_device{}());
    thermalNoiseDist = std::normal_distribution<double>(0.0, NOISE_SIGMA_WATTS);
    shadowingDist = std::normal_distribution<double>(0.0, SHADOWING_SIGMA_DB);

    scheduleAt(simTime() + 0.2, findCellsMsg);
}

void UE::handleMessage(cMessage *msg)
{
    if (msg->isSelfMessage() && strcmp(msg->getName(), "findCells") == 0) {
        cModule *parent = getParentModule();
        double minDistance = INFINITY;
        gNB *servingGNB = nullptr;

        for (int i = 0; i < parent->getSubmoduleVectorSize("gnbs"); i++) {
            gNB *gnb = check_and_cast<gNB *>(parent->getSubmodule("gnbs", i));
            double distance = calculateDistance(x, y, gnb->getX(), gnb->getY());

            if (distance < minDistance) {
                minDistance = distance;
                servingCellPCI = gnb->getPCI();
                servingGNB = gnb;
            }
        }

        if (servingGNB) {
            neighborCellPCIs = servingGNB->getNeighborPCIs();
        }

        createGridDictionary();
        calculateMeasurements();
        createVisualConnections();

        cMessage *updateMsg = new cMessage("updateMeasurements");
        scheduleAt(simTime() + 1.0, updateMsg);
    }
    delete msg;
}

void UE::calculateMeasurements()
{
    measurementReport = JsonValue();
    measurementReport.isObject = true;
    auto& samplesArray = measurementReport.object["samples"];
    samplesArray.isArray = true;

    cModule *parent = getParentModule();

    // Identify Serving Cell
    gNB *servingGNB = nullptr;
    for (int i = 0; i < parent->getSubmoduleVectorSize("gnbs"); i++) {
        gNB *gnb = check_and_cast<gNB *>(parent->getSubmodule("gnbs", i));
        if (gnb->getPCI() == servingCellPCI) {
            servingGNB = gnb;
            break;
        }
    }

    // Identify Closest Grid
    double minDistance_grid = INFINITY;
    int closestGridIndex = -1;
    double gridCenterX = 0, gridCenterY = 0;

    GridDeployer *grid = check_and_cast<GridDeployer *>(parent->getSubmodule("gridDeployer", 1));
    const std::vector<GridInfo>& gridCenters = grid->getGridCenters();
    for (const auto& gridInfo : gridCenters) {
        double distance_grid = calculateDistance(x, y, gridInfo.centerX, gridInfo.centerY);
        if (distance_grid < minDistance_grid) {
            minDistance_grid = distance_grid;
            gridCenterX = gridInfo.centerX;
            gridCenterY = gridInfo.centerY;
            closestGridIndex = gridInfo.index;
        }
    }

    auto& gridDetail = measurementReport.object["gridDetail"];
    gridDetail.isObject = true;
    gridDetail.object["gridId"].isNumber = true; gridDetail.object["gridId"].number = closestGridIndex;
    gridDetail.object["gridCenterX"].isNumber = true; gridDetail.object["gridCenterX"].number = gridCenterX;
    gridDetail.object["gridCenterY"].isNumber = true; gridDetail.object["gridCenterY"].number = gridCenterY;

    // Sampling Loop
    for (int sampleIdx = 0; sampleIdx < NUM_SAMPLES; ++sampleIdx) {
        JsonValue currentSample;
        currentSample.isObject = true;
        currentSample.object["sampleId"].isNumber = true;
        currentSample.object["sampleId"].number = sampleIdx;

        double thermal_noise_val = NOISE_MEAN_WATTS + thermalNoiseDist(rng);
        if (thermal_noise_val <= 1e-21) thermal_noise_val = 1e-21;

        double serving_shadowing = shadowingDist(rng);

        // A. Measure Serving
        auto& servingCellData = currentSample.object["servingCell"];
        servingCellData.isObject = true;

        if (servingGNB) {
            double servingDistance = calculateDistance(x, y, servingGNB->getX(), servingGNB->getY());

            servingCellData.object["pci"].isNumber = true; servingCellData.object["pci"].number = servingCellPCI;
            servingCellData.object["x"].isNumber = true; servingCellData.object["x"].number = servingGNB->getX();
            servingCellData.object["y"].isNumber = true; servingCellData.object["y"].number = servingGNB->getY();

            double rsrp = calculateRSRP(servingDistance, serving_shadowing, thermal_noise_val);
            double rssi = calculateRSSI(servingDistance, serving_shadowing, thermal_noise_val);
            double rsrq = calculateRSRQ(rsrp, rssi);

            double interference = calculateInterference(thermal_noise_val);
            double sinr = calculateSINR(rsrp, interference, thermal_noise_val);

            servingCellData.object["rsrp"].isNumber = true; servingCellData.object["rsrp"].number = rsrp;
            servingCellData.object["rssi"].isNumber = true; servingCellData.object["rssi"].number = rssi;
            servingCellData.object["rsrq"].isNumber = true; servingCellData.object["rsrq"].number = rsrq;
            servingCellData.object["sinr"].isNumber = true; servingCellData.object["sinr"].number = sinr;
        }

        // B. Measure Neighbors
        auto& neighborCellsData = currentSample.object["neighborCells"];
        neighborCellsData.isArray = true;

        for (int pci : neighborCellPCIs) {
            JsonValue neighborCell;
            neighborCell.isObject = true;
            neighborCell.object["pci"].isNumber = true; neighborCell.object["pci"].number = pci;

            gNB *neighborGNB = nullptr;
            for (int i = 0; i < parent->getSubmoduleVectorSize("gnbs"); i++) {
                gNB *gnb = check_and_cast<gNB *>(parent->getSubmodule("gnbs", i));
                if (gnb->getPCI() == pci) {
                    neighborGNB = gnb;
                    break;
                }
            }

            if (neighborGNB) {
                double neighbor_shadowing = shadowingDist(rng);
                double neighborDistance = calculateDistance(x, y, neighborGNB->getX(), neighborGNB->getY());
                neighborCell.object["x"].isNumber = true; neighborCell.object["x"].number = neighborGNB->getX();
                neighborCell.object["y"].isNumber = true; neighborCell.object["y"].number = neighborGNB->getY();

                double n_rsrp = calculateRSRP(neighborDistance, neighbor_shadowing, thermal_noise_val);
                double n_rssi = calculateRSSI(neighborDistance, neighbor_shadowing, thermal_noise_val);
                double n_rsrq = calculateRSRQ(n_rsrp, n_rssi);

                neighborCell.object["rsrp"].isNumber = true; neighborCell.object["rsrp"].number = n_rsrp;
                neighborCell.object["rssi"].isNumber = true; neighborCell.object["rssi"].number = n_rssi;
                neighborCell.object["rsrq"].isNumber = true; neighborCell.object["rsrq"].number = n_rsrq;
            }
            neighborCellsData.array.push_back(neighborCell);
        }
        samplesArray.array.push_back(currentSample);
    }
}

void UE::finish()
{
    if (!dataInitialized) {
        allUEData.isObject = true;
        allUEData.object["UEs"].isArray = true;
        allGridData.isObject = true;
        allGridData.object["GRIDs"].isArray = true;
        dataInitialized = true;
    }

    // Accumulate Data
    JsonValue ueData;
    ueData.isObject = true;
    ueData.object["id"].isNumber = true; ueData.object["id"].number = getId();
    ueData.object["position"].isObject = true;
    ueData.object["position"].object["x"].isNumber = true; ueData.object["position"].object["x"].number = x;
    ueData.object["position"].object["y"].isNumber = true; ueData.object["position"].object["y"].number = y;
    ueData.object["gridDetail"] = measurementReport.object["gridDetail"];
    ueData.object["samples"] = measurementReport.object["samples"];

    allUEData.object["UEs"].array.push_back(ueData);

    // Grid Data (Once)
    if (ueFinishedCount == 0) {
        JsonValue gridData;
        gridData.isObject = true;
        gridData.object["gridDictionary"] = gridReport.object["gridDictionary"];
        allGridData.object["GRIDs"].array.push_back(gridData);
    }

    // 2. Count this finished UE
    ueFinishedCount++;

    // 3. Compare with total initialized UEs
    // This works perfectly regardless of vector/scalar definitions
    if (ueFinishedCount == totalUEsInitialized) {
        EV << "All " << totalUEsInitialized << " UEs finished. Writing JSON to file..." << endl;

        const char *outputDir = getSimulation()->getActiveEnvir()->getConfigEx()->getVariable(CFGVAR_RESULTDIR);
        std::string filePath = std::string(outputDir) + "/all_measurements.json";

        std::ofstream file(filePath);
        if (file.is_open()) {
            file << jsonToString(allUEData);
            file.close();
            EV << "File saved successfully: " << filePath << endl;
        } else {
            EV << "Error: Unable to open file: " << filePath << endl;
        }

        // Reset counters for next run (if batch simulation)
        ueFinishedCount = 0;
        totalUEsInitialized = 0;
        dataInitialized = false;
        allUEData = JsonValue();
        allGridData = JsonValue();
    }
}

// ... [Helper Calculations - Same as before] ...
double UE::calculateRSRP(double distance, double shadowing_db, double thermal_noise_watts) {
    double txPower = 43.0; double frequency = 2.1; double N = 25.0; double numRef = N * 2.0;
    double fspl = 20.0 * log10(distance) + 20.0 * log10(frequency) + 32.44;
    double clean_rsrp_dbm = txPower - 10.0*log10(numRef) - fspl + shadowing_db;
    double clean_rsrp_watts = pow(10.0, (clean_rsrp_dbm - 30.0) / 10.0);
    double noisy_rsrp_watts = clean_rsrp_watts + thermal_noise_watts;
    if (noisy_rsrp_watts <= 1e-21) noisy_rsrp_watts = 1e-21;
    double final = 10.0 * log10(noisy_rsrp_watts) + 30.0;
    return (final > -40.0) ? -40.0 : final;
}

double UE::calculateInterference(double thermal_noise_watts) {
    cModule *parent = getParentModule();
    double totalIntWatts = 0.0;
    for (int i = 0; i < parent->getSubmoduleVectorSize("gnbs"); i++) {
        gNB *gnb = check_and_cast<gNB *>(parent->getSubmodule("gnbs", i));
        if (gnb->getPCI() != servingCellPCI) {
            double d = calculateDistance(x, y, gnb->getX(), gnb->getY());
            double shad = shadowingDist(rng);
            double int_rsrp_dbm = calculateRSRP(d, shad, thermal_noise_watts);
            totalIntWatts += pow(10.0, (int_rsrp_dbm - 30.0) / 10.0);
        }
    }
    if (totalIntWatts <= 1e-21) return -120.0;
    return 10.0 * log10(totalIntWatts) + 30.0;
}

double UE::calculateRSSI(double d, double shad, double noise) {
    double rsrp_dbm = calculateRSRP(d, shad, noise);
    double int_dbm = calculateInterference(noise);
    double rsrp_w = pow(10.0, (rsrp_dbm - 30.0) / 10.0);
    double int_w = pow(10.0, (int_dbm - 30.0) / 10.0);
    double total = rsrp_w * (25.0 * 12.0) + int_w + noise;
    return 10.0 * log10(total) + 30.0;
}

double UE::calculateRSRQ(double rsrp, double rssi) {
    double rsrp_l = pow(10.0, (rsrp-30.0)/10.0);
    double rssi_l = pow(10.0, (rssi-30.0)/10.0);
    if(rssi_l <= 1e-21) return -20.0;
    return 10.0 * log10((25.0 * rsrp_l) / rssi_l);
}

double UE::calculateSINR(double rsrp, double interf, double noise) {
    double sig = pow(10.0, (rsrp-30)/10);
    double inf = pow(10.0, (interf-30)/10);
    if(noise<=1e-21) noise=1e-21;
    return 10.0*log10(sig/(inf+noise));
}

void UE::connectToCell(gNB *gnb, bool isServingCell) {
    const char* gateName = isServingCell ? "servingCell" : "neighborCell";
    int gateIndex = isServingCell ? 0 : gateSize("neighborCell");
    if (!isServingCell) setGateSize("neighborCell", gateIndex + 1);
    cGate *outGate = isServingCell ? gate("servingCell$o") : addGate(gateName, cGate::OUTPUT);
    cGate *inGate = isServingCell ? gate("servingCell$i") : addGate(gateName, cGate::INPUT);
    int gnbPortIndex = gnb->gateSize("uePort");
    gnb->ensureUEPortExists(gnbPortIndex);
    outGate->connectTo(gnb->gate("uePort$i", gnbPortIndex));
    gnb->gate("uePort$o", gnbPortIndex)->connectTo(inGate);
    const char* color = isServingCell ? "red" : "blue";
    int width = isServingCell ? 3 : 1;
    outGate->getDisplayString().setTagArg("ls", 0, color);
    outGate->getDisplayString().setTagArg("ls", 1, width);
    inGate->getDisplayString().setTagArg("ls", 0, color);
    inGate->getDisplayString().setTagArg("ls", 1, width);
}

gNB* UE::findGNBByPCI(int pci) {
    cModule *parent = getParentModule();
    for (int i = 0; i < parent->getSubmoduleVectorSize("gnbs"); i++) {
        gNB *gnb = check_and_cast<gNB *>(parent->getSubmodule("gnbs", i));
        if (gnb->getPCI() == pci) return gnb;
    }
    return nullptr;
}

void UE::createGridDictionary() {
    gridReport.isObject = true;
    auto& gridDictionary = gridReport.object["gridDictionary"];
    gridDictionary.isArray = true;
    cModule *parent = getParentModule();
    GridDeployer *grid = check_and_cast<GridDeployer *>(parent->getSubmodule("gridDeployer", 1));
    const std::vector<GridInfo>& gridCenters = grid->getGridCenters();
    for (const auto& gridInfo : gridCenters) {
        JsonValue gridCell;
        gridCell.isObject = true;
        gridCell.object["gridId"].isNumber = true; gridCell.object["gridId"].number = gridInfo.index;
        gridCell.object["gridCenterX"].isNumber = true; gridCell.object["gridCenterX"].number = gridInfo.centerX;
        gridCell.object["gridCenterY"].isNumber = true; gridCell.object["gridCenterY"].number = gridInfo.centerY;
        gridDictionary.array.push_back(gridCell);
    }
}

void UE::createVisualConnections() {
    cModule *parent = getParentModule();
    for (int i = 0; i < gateSize("toGNB"); ++i) { if (gate("toGNB", i)->isConnected()) gate("toGNB", i)->disconnect(); }
    int requiredGates = 1 + neighborCellPCIs.size();
    if (gateSize("toGNB") < requiredGates) setGateSize("toGNB", requiredGates);
    int gateIndex = 0;
    for (int i = 0; i < parent->getSubmoduleVectorSize("gnbs"); i++) {
        gNB *gnb = check_and_cast<gNB *>(parent->getSubmodule("gnbs", i));
        if (gnb->getPCI() == servingCellPCI) {
            cDatarateChannel *ch = cDatarateChannel::create("servingChannel");
            if(ch) {
                ch->setDatarate(1e6);
                int gidx = 0; while(gnb->gate("fromUE", gidx)->isConnected()) gidx++;
                gate("toGNB", gateIndex)->connectTo(gnb->gate("fromUE", gidx), ch);
                gate("toGNB", gateIndex)->getDisplayString().parse("ls=red,1.5,DASHED");
                gateIndex++;
            }
            break;
        }
    }
    for (int pci : neighborCellPCIs) {
        for (int i = 0; i < parent->getSubmoduleVectorSize("gnbs"); i++) {
            gNB *gnb = check_and_cast<gNB *>(parent->getSubmodule("gnbs", i));
            if (gnb->getPCI() == pci) {
                cDatarateChannel *ch = cDatarateChannel::create("neighborChannel");
                if(ch) {
                    ch->setDatarate(50e6); ch->setDelay(2e-6);
                    int gidx = 0; while(gnb->gate("fromUE", gidx)->isConnected()) gidx++;
                    gate("toGNB", gateIndex)->connectTo(gnb->gate("fromUE", gidx), ch);
                    gate("toGNB", gateIndex)->getDisplayString().parse("ls=blue,1,DASHED");
                    gateIndex++;
                }
                break;
            }
        }
    }
}

double UE::calculateDistance(double x1, double y1, double x2, double y2) {
    return std::sqrt(std::pow(x2 - x1, 2) + std::pow(y2 - y1, 2));
}

std::string UE::jsonToString(const JsonValue& json, int indent) {
    std::ostringstream oss;
    std::string indentStr(indent, ' ');
    if (json.isObject) {
        oss << "{\n";
        bool first = true;
        for (const auto& pair : json.object) {
            if (!first) oss << ",\n";
            first = false;
            oss << indentStr << "  \"" << pair.first << "\": " << jsonToString(pair.second, indent + 2);
        }
        oss << "\n" << indentStr << "}";
    } else if (json.isArray) {
        oss << "[\n";
        bool first = true;
        for (const auto& element : json.array) {
            if (!first) oss << ",\n";
            first = false;
            oss << indentStr << "  " << jsonToString(element, indent + 2);
        }
        oss << "\n" << indentStr << "]";
    } else if (json.isString) {
        oss << "\"" << json.string << "\"";
    } else if (json.isNumber) {
        oss << json.number;
    }
    return oss.str();
}
